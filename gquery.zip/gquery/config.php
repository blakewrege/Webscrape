<?php
$GLOBALS['config'] = array(
    'googleQueryURL' => 'https://www.google.com/search?q=%query%', // %query% will get replaced with the specified query.
    'endpoint' => 'http://enterprise.majesticseo.com/api_command',
    'app_api_key' => '9567203E99237B47F930D9DEBE79C3FE',
    'backlinkURLs' => 200
);
?>