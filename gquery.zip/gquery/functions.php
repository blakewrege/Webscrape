<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
require_once('config.php');

require_once('simplehtmldom_1_5/simple_html_dom.php');
$path = 'majesticseo_external_rpc/';
set_include_path(get_include_path() . PATH_SEPARATOR . $path);
require_once('majesticseo-external-rpc/APIService.php');

set_time_limit(0);

function getKeywordQuery($q, $num, $keywords) {
    $queries = array();
    foreach ($keywords as $kw) {
        $queries[] = str_replace('%q%', $q, html_entity_decode($kw));
    }

    $data = array();
    $count = 1;
    foreach ($queries as $qq) {
        $data = array_merge($data, getGoogleQuery($qq, $num, false, true, ($count == 1)));
        $data[] = array('', '', '');
        $count++;
    }

    return $data;
}

function getKeywords() {
    $filename = dirname($_SERVER['SCRIPT_FILENAME']) . '/keywords.txt';
    if (!file_exists($filename)) { die('Keyword file does not exist.  Please create it and try again.'); }
    $c = file_get_contents($filename);
    $str = '';
    foreach (explode("\n", $c) as $cc) {
        $str .= ('<option value="' . htmlentities($cc) . '">' . $cc . '</option>');
    }
    return $str;
}

function getGoogleQuery($q, $num=100, $majesticData=true, $includeQuery=false, $includeHeaders=true) {


    $url = str_replace('%query%', urlencode(stripslashes($q)), $GLOBALS['config']['googleQueryURL']) . '&num=100';
    $amt = $num + 6; // Additional allowance to get around google URLs like news links, etc.
    $page = 1;
    $perPage = 100;


    // Load up what google URLs we're going to scrape.
    $urls = array();
    do {
        $tUrl = $url;
        if ($page > 1) {
            $tUrl .= '&start=' . (($page - 1) * $perPage);
        }
        $nAmt = min(100, $amt);
        $urls[] = $tUrl;
        $amt -= $nAmt;
        $page++;
    } while ($amt > 0);

    // Pull in the Google requests.
    $cData = array();
    foreach ($urls as $u) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $u);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.1) Gecko/20061204 Firefox/2.0.0.1');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $body = curl_exec($ch);
        $cData[] = $body;
    }
    
    // Now parse it and query Majestic
    if ($includeHeaders) {
        if ($majesticData) {
            $data = array(array('Rank', 'URL', 'Title', 'Description', 'Source URL', 'AC Rank', 'Anchor Text', 'Is Redirect?', 'Has Alt Text?', 'Target URL'));
        } else {
            $data = array(array('Rank', 'Query', 'URL'));
        }
    } else {
        $data = array();
    }
    $rank = 1;
    foreach($cData as $c) {
        $html = str_get_html($c);
        foreach($html->find('li.g') as $r) {
            foreach ($r->find('h3.r a') as $rr) { 
                $fURL = $rr->href;
                $tTitle = html_entity_decode($rr->plaintext);
                break;
            }

            if (substr($fURL, 0, strlen('/url?q=')) == '/url?q=') {
                $fURL = substr($fURL, strlen('/url?q='));
            }

            $fURL = preg_replace('/&.+$/', '', $fURL);

            if (substr($fURL, 0, 1) == '/' || $fURL == '' || substr($fURL, 0, strlen('http://maps.google.com')) == 'http://maps.google.com') {// Means it's an internal Google link or didn't have a URL
                continue;
            }
            if ($majesticData) {
                foreach ($r->find('div.s') as $ds) {
                    $descRaw = $ds->innertext;
                    $divLoc = strpos($descRaw, '<div>');
                    if ($divLoc !== false) {
                        $ds->innertext = str_replace(array('<b>', '</b>', '<br>'), '', substr($descRaw, 0, $divLoc));
                    }
                    $tDescription = html_entity_decode($ds->plaintext);
                }
            
                // Now do Majestic stuff
                $parameters = array();
                $parameters["MaxSourceURLs"] = $GLOBALS['config']['backlinkURLs'];
                $parameters["URL"] = $fURL;
                $parameters["GetUrlData"] = 1;
                $parameters["MaxSourceURLsPerRefDomain"] = 1;
                $parameters["datasource"] = "fresh";
                
                $api_service = new APIService($GLOBALS['config']['app_api_key'], $GLOBALS['config']['endpoint']);
                $response = $api_service->executeCommand("GetTopBackLinks", $parameters);
                $blData = array();
                $tables = $response->getTables();
                if (count($tables) > 0) {
                    $t = $tables['URL'];
                    foreach ($t->getTableRows() as $row) {
                        $blData[] = array(
                            'rank' => $rank,
                            'url' => $fURL,
                            'title' => $tTitle,
                            'description' => $tDescription,
                            'sourceURL' => $row['SourceURL'],
                            'ACRank' => $row['ACRank'],
                            'anchorText' => $row['AnchorText'],
                            'isRedirect' => (intval($row['FlagRedirect']) ? 'Yes' : 'No'),
                            'hasAltText' => (intval($row['FlagAltText']) ? 'Yes' : 'No'),
                            'targetURL' => $row['TargetURL']
                            );
                    } 
                }
                $data = array_merge($data, $blData);
            } else {
                $data[] = array($rank, $q, $fURL);
            }

            $rank++;
            if ($rank > $num) { break; } 
        }
    }
    return $data;
}

function toCSV($data) {
    $csv = tmpfile();
    foreach($data as $d) {
        fputcsv($csv, $d);
    }
    header('Content-type: text/csv');
    header('Content-Disposition: attachment; filename="downloaded.csv"');
    $stats = fstat($csv);
    fseek($csv, 0);
    echo fread($csv, $stats['size']);
    fclose($csv);
} 

?>