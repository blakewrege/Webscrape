<?php require_once('functions.php'); ?>
<html>
	<head>
	<title>SEO Query Analyzer</title>
    <style>
    div.row { margin-top: 5px;}
    </style>
	</head>
	<body>
        <div id="majesticFormD">
            <h2>Majestic SEO Query</h2>
    		<form name="gqueryForm" id="gqueryForm" action="process.php" method="post">
    		<div class="row"><label for="qTxt">Query: </label><input type="text" size="30" name="q" id="qTxt" /></div>
            <div class="row"><label for="nTxt">Results to Parse (maximum 200): </label><input type="text" size="30" name="n" id="nTxt" /></div>
            <input type="hidden" name="queryType" value="majestic" />
    		<div class="row"><input type="submit" value="Submit" name="submit" /></div>
            </form>
        </div>
        
        <div id="keywordFormD" style="margin-top:80px;">
            <h2>Keyword Query</h2>
            <form name="gquery2Form" id="gquery2Form" action="process.php" method="post">
            <div class="row"><label for="qTxt">Query: </label><input type="text" size="30" name="q" id="qTxt" /></div>
            <div class="row"><label for="nTxt">Google Results to Parse per keyword (maximum 200): </label><input type="text" size="30" name="n" id="nTxt" /></div>
            <div class="row"><label for="kSlct">Keywords</label></div>
            <select multiple size="10" id="kSlct" name="k[]">
            <?php echo getKeywords(); ?>
            </select></div>
            <input type="hidden" name="queryType" value="keyword" />
            <div class="row"><input type="submit" value="Submit" name="submit" /></div>
            </form>
	</body>
</html>