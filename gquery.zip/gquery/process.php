<?php

require_once('functions.php');

if (!isset($_POST['queryType'])) {
    die('Invalid query.');
}

if (intval($_POST['n']) > 200 || intval($_POST['n'] == 0)) { die('You must request between 1 and 200 results from Google.'); }

if ($_POST['queryType'] == 'majestic') {
    $data = getGoogleQuery($_POST['q'], intval($_POST['n']));
} else if ($_POST['queryType'] == 'keyword') {
    $data = getKeywordQuery($_POST['q'], intval($_POST['n']), $_POST['k']);
}

toCSV($data);
exit;   


?>